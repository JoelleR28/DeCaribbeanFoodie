/**
 * Primary editor script.
 *
 * @package   MembersBlockPermissions
 * @author    The MemberPress Team 
 * @copyright 2019 The MemberPress Team
 * @license   https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
 * @link      https://members-plugin.com/-block-permissions
 */

import filterBlockEdit     from './editor/filter-block-edit';
import filterBlockRegister from './editor/filter-block-register';
