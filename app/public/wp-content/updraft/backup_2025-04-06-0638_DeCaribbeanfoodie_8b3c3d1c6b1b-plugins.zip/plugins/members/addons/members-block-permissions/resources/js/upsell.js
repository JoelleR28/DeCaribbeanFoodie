/**
 * Upsell script.
 *
 * @package   MembersBlockPermissions
 * @author    The MemberPress Team
 * @copyright 2025 The MemberPress Team
 * @license   https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
 */

import MembersUpsell from './editor/filter-block-upsell';
